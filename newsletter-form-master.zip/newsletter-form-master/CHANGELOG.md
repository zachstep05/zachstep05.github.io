# Changelog

All Notable changes to `newsletter-form` will be documented in this file

## 2.0.2
- Allow jQuery 3.0

## 2.0.1
### Changed
- Default DOM classes

## 2.0.0
### Changed
- Extra option for submit button
- Disable button on submit, enable on response

## 1.0.3
### Fixed
- Bug when using no custom options

## 1.0.2
### Fixed
- Improved readability

## 1.0.1
### Fixed
- Better syntax

## 1.0.0
- Initial release
